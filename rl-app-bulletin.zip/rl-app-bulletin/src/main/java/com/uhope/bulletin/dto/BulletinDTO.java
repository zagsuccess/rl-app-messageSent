package com.uhope.bulletin.dto;

import com.uhope.bulletin.domain.Bulletin;

/**
 * @author: StivenYang
 * @date: 2018/9/8
 * @description: 暗查暗访表-DTO数据传输对象
 */
public class BulletinDTO extends Bulletin {
}
