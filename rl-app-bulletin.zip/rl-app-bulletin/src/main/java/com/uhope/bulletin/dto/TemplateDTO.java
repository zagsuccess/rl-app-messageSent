package com.uhope.bulletin.dto;
import com.uhope.bulletin.domain.Template;

/**
 * 模版表-DTO数据传输对象类
 * @author ChenBin on 2018/09/04
 */
public class TemplateDTO extends Template {

}
