package com.uhope.bulletin.mapper;

import com.uhope.core.Mapper;
import com.uhope.bulletin.domain.Template;

public interface TemplateMapper extends Mapper<Template> {
}